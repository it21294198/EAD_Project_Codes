package com.example.ecommerce.Model

data class Customer(
    val email: String,
    val firstName: String,
    val lastName: String,
    val creationDate: String
)