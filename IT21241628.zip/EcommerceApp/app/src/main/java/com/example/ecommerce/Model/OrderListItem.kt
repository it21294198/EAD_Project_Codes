package com.example.ecommerce.Model

data class OrderListItem (
    val itemName: String,
    val status: String,
    val date: String
)