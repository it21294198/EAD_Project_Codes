package com.example.ecommerce.Modelodel

data class Review(
    val userEmail: String,
    val comment: String,
    val reviewDate: String
)
